#include <stdio.h>
#include<stdlib.h>

struct Node
{
    int data;
    struct Node*next;
};

void linkedListtraversal(struct Node*ptr) {
    while (ptr!=NULL)
    {
        printf("Enter element %d", ptr->data);
        ptr = ptr->next;
    }

struct Node*insertAtbeginning(struct Node*head, int data) {
    struct Node*ptr = (struct Node*) malloc(sizeof(struct Node));
    ptr->next = head;
    ptr->data = data;
    return ptr;
}
}

int main() {
    struct Node*head;
    struct Node*second;
    struct Node*third;
    struct Node*fourth;

    head = (struct Node*) malloc(sizeof(struct Node));
    second = (struct Node*) malloc(sizeof(struct Node));
    third = (struct Node*) malloc(sizeof(struct Node));
    fourth = (struct Node*) malloc(sizeof(struct Node));

    head->data = 31;
    head->next = second;

    second->data = 46;
    second->next = third;

    third->data = 52;
    third->next = fourth;

    fourth->data = 55;
    fourth->next = NULL; 
    printf("Linked list before insertion\n");
    linkedListtraversal(head);
    head = insertAtbeginning(head, 30);
    printf("Linked list after insertion\n");
    linkedListtraversal(head);

    return 0;
}