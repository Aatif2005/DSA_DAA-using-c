/*#include<stdio.h>
#include<stdlib.h>  

struct Node
{
    int data;
    struct Node *next;
};

void linkedlistTraversal(struct Node *head) {
    struct Node *ptr = head;
    do
    {
       printf("Element is %d\n", ptr->data);
       ptr = ptr->next;
    } while (ptr!=head);
    
}

struct Node *insertionatFirst(struct Node *head, int data) {
    struct Node *ptr = (struct Node *)malloc(sizeof(struct Node));
    ptr->data = data;
    struct Node *p = head->next;
    while (p->next != head)
    {
        p = p->next;
    }
    p->next = ptr;
    ptr->next = head;
    return ptr;
}

int main() {
    struct Node *head;
    struct Node *second;
    struct Node *third;
    struct Node *fourth;

    head = (struct Node *)malloc(sizeof(struct Node));
    second = (struct Node *)malloc(sizeof(struct Node));
    third = (struct Node *)malloc(sizeof(struct Node));
    fourth = (struct Node *)malloc(sizeof(struct Node));

    head->data = 31;
    head->next = second;

    second->data = 46;
    second->next = third;

    third->data = 52;
    third->next = fourth;

    fourth->data = 55;
    fourth->next = head; 
    printf("Linked list before insertion\n");
    linkedlistTraversal(head);
    head = insertionatFirst(head, 30);
    printf("Linked list after insertion\n");
    linkedlistTraversal(head);

    return 0;
}*/
// deletion in circular linked list

#include<stdio.h>
#include<stdlib.h>

struct Node
{
    int data;
    struct Node *next;
};

void linkedlistTraversal(struct Node *head) {
    struct Node *ptr = head;
    do
    {
        printf("Element is %d\n", ptr->data);
        ptr = ptr->next;
    } while (ptr!=head);
}

struct Node *deletionatFirst(struct Node *head) {
    struct Node *ptr = head;
    struct Node *p = head->next;
    while (p->next != head)
    {
        p = p->next;
    }
    p->next = head->next;
    head = head->next;
    free(ptr);
    return head;
}
int main() {
    struct Node *head;
    struct Node *second;
    struct Node *third;
    struct Node *fourth;

    head = (struct Node *)malloc(sizeof(struct Node));
    second = (struct Node *)malloc(sizeof(struct Node));
    third = (struct Node *)malloc(sizeof(struct Node));
    fourth = (struct Node *)malloc(sizeof(struct Node));

    head->data = 31;
    head->next = second;

    second->data = 46;
    second->next = third;

    third->data = 52;
    third->next = fourth;

    fourth->data = 55;
    fourth->next = head; 
    printf("Linked list before deletion\n");
    linkedlistTraversal(head);
    head = deletionatFirst(head);
    printf("Linked list after deletion\n");
    linkedlistTraversal(head);

    return 0;
}       
